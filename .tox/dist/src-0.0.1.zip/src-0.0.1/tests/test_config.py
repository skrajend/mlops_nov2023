
def test_generic() :
    a = 30
    b = 40
    assert a != b

def test_generic1() :
    a = 30
    b = 40
    assert a == b